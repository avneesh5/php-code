<pre>
<?php
$arr=array(5=>200,11=>700,13=>1500);
print_r($arr);



?>
