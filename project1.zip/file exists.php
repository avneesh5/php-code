<pre>
<?php
echo file_exists("hi.txt"); //1



?>