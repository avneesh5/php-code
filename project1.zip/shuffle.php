<pre>
<?php
$arr=array("ram","Ram","sam","Sam");
echo shuffle($arr);  
print_r($arr);

?>