<?php
$str="using this method we can get a substring from a string";
echo substr($str,10);
//from 10th position we can get all the charactors
echo substr($str,0,20);



?>