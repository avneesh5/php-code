<!DOCTYPE html>
    <html>
<head>
</head>
<body>
<h1>person1</h1>
<form method="POST" action="savep2.php">    
Number1:<input type="text" name="num1">
<input type="submit" value="go">
    </form>
    </body>
    </html>