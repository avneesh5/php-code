<?php
echo strtotime("10days");
echo date("Y-M-d h:i:s strtotime(10days 3years)");
//converting the number of second into date formats 


?>