<?php
echo setcookie("city","hyd");
echo setcookie("state","TS");


?>