<pre>
<?php
$name="Ram\'s";
echo stripslashes($name);

?>