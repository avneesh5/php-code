<?php
$x=100;
$y=200;
$z=$x+$y;
echo 'the sum is:'.$z;
echo 'the sum of'.$x.'and'.$y.'is:'.$z;



?>