<pre>
<?php
$arr=array("abc","def","ghi",10,20,30,40);
echo array_search(20,$arr);  //4
echo array_search("def",$arr);  //1



?>