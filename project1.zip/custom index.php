<pre>
<?php
$arr=array(12=>20,30,15=>50,60);
$c=count($arr);
foreach($arr as $x=>$y)
{
echo $x."-".$y."<br>";
}

?>