<?php
$table=20;
for($i=1;$i<=10;$i++)
{
echo $table."*".$i."=".$table*$i."<br>";
}



?>