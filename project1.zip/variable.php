<?php
$x=180;
$name="ram";
$price=10.5;
$subject="php";
$status=true;
echo $subject;




?>