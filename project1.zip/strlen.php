<?php
$str="welcome to php";
echo strlen($str);   //14
echo strlen("welcome"); //7

?>