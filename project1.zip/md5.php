<pre>
<?php
$pwd="ram@123";
echo md5($pwd); //3db66ceb605c1bcb779c63e180c4f2d0    32bit
?>