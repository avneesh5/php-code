<?php
echo time();
?>