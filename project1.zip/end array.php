<pre>
<?php
$arr=array("ram","Ram","sam","Sam");
echo end($arr);  //Sam
echo prev($arr); //sam

?>