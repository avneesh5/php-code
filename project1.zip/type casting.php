<?php
$x="100.5";
(int)$x;
(float)$x;
(bool)$x;
(double)$x;
(array)$x;
(object)$x;




?>