<pre>
<?php
$a1=array(10,20,30,40,10,50,20,70,10,80);
$fa=array_unique($a1);
print_r($fa);



?>