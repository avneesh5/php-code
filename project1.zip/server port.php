<pre>
<?php
echo $_SERVER['SERVER_PORT'];   //80
?>