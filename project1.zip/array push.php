<pre>
<?php
$arr=array(10,20,30,40,50);
echo array_push($arr,70); //6
print_r($arr);


?>