<pre>
<?php
echo $_SERVER['SERVER_PROTOCOL'];
?>        //  HTTP/1.1 