<pre>
<?php
echo $_SERVER['PHP_SELF'];
?>