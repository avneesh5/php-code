<?php
$x=true;
echo $x; //1














//
$x
    //echo $x;  //error will come
?>