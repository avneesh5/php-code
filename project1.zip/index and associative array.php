<pre>
<?php
$user=array(
"city"=>"amh",
"state"=>"UP",100,200
);
print_r($user);
?>