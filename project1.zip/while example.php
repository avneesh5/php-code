<?php
$table=19;
$i=1;
while($i<=10)
{
echo $table."*".$i."=".$table*$i;
echo "<br>";
$i++;
}

?>