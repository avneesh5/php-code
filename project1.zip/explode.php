<pre>
<?php
$str="10*20*30*40*50*60*70*80*90";
$arr=explode("*",$str);
print_r($arr);

?>