<pre>
<?php
$arr=array("Ram","Sam","Tam","abc","hin");
echo arsort($arr);
print_r($arr);

?>