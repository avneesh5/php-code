<pre>
<?php
$arr=array(10,20,30,40,50);
$c=count($arr);
for($i=0;$i<$c;$i++)
{
    echo $arr[$i]."<br>";
    
}

?>