<pre>
<?php
$user=array(
"City"=>"HYD",
"State"=>"TS"
);
$vls=array_values($user);
print_r($vls);


?>