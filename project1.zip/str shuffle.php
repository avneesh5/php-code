<pre>
<?php
$num=1234567890;
echo str_shuffle($num);


?>