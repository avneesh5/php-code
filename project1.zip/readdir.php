<pre>
<?php
$folder="images";
$dp=opendir("cc");
while($file=readdir($dp))
{
echo $file."<br>";
}

?>