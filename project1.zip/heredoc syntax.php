<?php
$str=<<<EOD
    example of string spanning multiple line 
    using heredoc syntax
    EOD;
echo $str;







?>