<pre>
<?php
$arr=array(
array(10,20,30),
array("a","b","c"),
array("Ram","Sam","ghanshyam"),
array(100,200,500),
);
print_r($arr);

?>