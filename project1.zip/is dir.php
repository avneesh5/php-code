<pre>
<?php
echo is_dir("cc"); //1



?>