<?php
$x=100;
$x=10;
echo $x;  //10

?>