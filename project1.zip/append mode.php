<pre>
<?php
$fp=fopen("hi.txt","a");
echo fwrite($fp,"this is php");


?>