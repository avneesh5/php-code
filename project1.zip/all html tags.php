<?php
echo "start";
?>
<html>
<head>
<title>test file</title>      
</head>
<body>
<h1>welcome to php</h1>
<input type="text" value="<?php echo "ram";?>">   <br><br> 
</body>
</html>
<?php
echo "end";
?>