<pre>
<?php
$a1=array(10,20,30,40);
$a2=array(100,200,300,400);
$fa=array_combine($a1,$a2);

print_r($fa);



?>