<?php
$x=100;
$y=200;
echo($x);   //100200
echo $y;

?>