<pre>
<?php
$pwd="cmFtQDEyMw==";
echo base64_decode($pwd); //ram@123


?>