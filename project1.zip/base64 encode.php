<?php
$pwd="ram@123";
echo base64_encode($pwd);
//cmFtQDEyMw==

?>