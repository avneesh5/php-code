<pre>
<?php
$arr=array("Ram","Sam","Tam","abc","hin");
echo sort($arr);
print_r($arr);

?>