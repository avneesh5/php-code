<pre>
<?php
$arr=array(10,20,30,40,50,60,70,80,90,100);
$fa=array_slice($arr,5);
//get all the element from 5th position
$fa=array_slice($arr,5,3);
//get 3 element from 5th position
print_r($fa);  //ram


?>