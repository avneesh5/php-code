<?php
$x=100;
$y=200;
$k=print$x; //100
echo "<br>";
echo $k; //1
?>