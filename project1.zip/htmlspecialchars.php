<?php
$str="<br>Welcome</br>";
echo htmlspecialchars($str);


?>