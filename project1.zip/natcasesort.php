<pre>
<?php
$users=array("ram","Ram","sam","Sam","tam","Tam");
natcasesort($users);
print_r($users);




?>