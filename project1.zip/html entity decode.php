<?php
$str="<br>Welcome</br>";
echo html_entity_decode("&lt;b&gt;Welcome&lt;/b&gt;");  //Welcome


?>