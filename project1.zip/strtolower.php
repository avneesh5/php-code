<pre>
<?php
$str="AvnEEsh kumar mishra";
echo strtolower($str);
?>

