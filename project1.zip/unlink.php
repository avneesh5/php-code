<pre>
<?php
$file="welcome.txt";
if(file_exists($file))
{
unlink($file);
echo "file deleted";
}
else
{
echo "unable to locate the file";
}

?>