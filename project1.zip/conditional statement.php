<?php
$m=93;
if($m>=90)
{
echo "Grade A";
}
else if($m>=80)
{
echo "Grade B";
}
else if($m>=70)
{
echo "Grade C";
}
else if($m>=60)
{
echo "Grade D";
}
else
{
echo "Fail";
}

?>