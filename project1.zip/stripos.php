<?php
$email="avms@gmail.com";
echo stripos($email,"Mail"); //6

?>