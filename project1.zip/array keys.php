<pre>
<?php
$user=array(
"City"=>"HYD",
"State"=>"TS"
);
$vls=array_keys($user);
print_r($vls);


?>