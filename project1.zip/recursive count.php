<pre>
<?php
$arr=array(
array(10,20,30),
array("a","b"),
);
echo count($arr,true); //7



?>