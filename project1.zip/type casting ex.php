<?php
$x="welcome";
$x=(bool) $x;
echo $x;
var_dump($x);
?>