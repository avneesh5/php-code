<pre>
<?php
print_r($_POST);
$name=$_POST['Name'];
$mail=$_POST['Email'];
$mobile=$_POST['Mobile'];
$msg=$_POST['Message'];
?>