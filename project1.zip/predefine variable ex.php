<?php
$x="true";
echo is_bool($x); //
echo is_string($x);  //1

?>