<pre>
<?php
$user=array(
"city"=>"hydderabad",
"state"=>"ts",
"pincode"=>500032
);
foreach($user as $x=>$y)
{
echo $x."=".$y."<br>";
}
?>