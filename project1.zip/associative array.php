<pre>
<?php
$user=array(
"Name"=>"Ram",
"City"=>"amh",
"State"=>"UP"
);
print_r($user);

?>