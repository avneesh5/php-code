<pre>
<?php
echo $_SERVER['SCRIPT_FILENAME'];
?>
//      C:/xampp/htdocs/aviproject1/script filename.php