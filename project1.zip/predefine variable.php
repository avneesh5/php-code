<?php
$x="100";
echo is_string($x); //1
echo is_int($x);


?>