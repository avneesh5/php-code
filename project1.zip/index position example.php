<pre>
<?php
$arr=array(12=>20,30,40,10=>50,60,70);
print_r($arr);

?>