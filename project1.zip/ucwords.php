<pre>
<?php
$str="avneesh kumar mishra";
echo ucwords($str);
?>

