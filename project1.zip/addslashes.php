<pre>
<?php
$name="Ram\'s";
echo addslashes($name);
    
?>