<pre>
<?php
$x=100;
$arr=array(10,20,30);
print_r($arr);
print_r($x);
?>