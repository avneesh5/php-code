<pre>
<?php
$arr=array("ram","Ram","sam","Sam");
echo next($arr);  //Ram


?>