<pre>
<?php
echo mkdir("js"); //1//by default all
echo mkdir("js",0644); //1




?>