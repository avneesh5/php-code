<?php
echo "welcome to home page";
echo "<br>";
echo "this is php class";
echo "<br>";
echo "azamgarh";
?>