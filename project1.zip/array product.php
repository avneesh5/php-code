<pre>
<?php
$arr=array(10,10.5,true,"hello");
echo array_sum($arr);   //21.5
echo array_product($arr);  //0
?>