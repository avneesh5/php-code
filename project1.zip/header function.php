<?php
echo "welcome";
header("location:home.php");
header("location:https://google.com");

?>