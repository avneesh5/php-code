<pre>
<?php
$arr=array("Ram","Sam","Tam","abc","hin");
echo krsort($arr);
print_r($arr);

?>