<pre>
<?php
$arr=array(10,20,30,40,50);
echo array_key_exists(4,$arr); //1



?>