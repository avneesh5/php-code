<pre>
<?php
$arr=array(10,20,30,40,50,60);
echo array_shift($arr); //10
print_r($arr);


?>