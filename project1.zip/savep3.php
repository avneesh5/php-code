<!DOCTYPE html>
    <html>
<head>
</head>
<body>
<h1>person3</h1>
<form method="POST" action="savep4.php">    
Number3:<input type="text" name="num3">
<input type="submit" value="go">
    </form>
    </body>
    </html>
<?php
setcookie("value2",$_POST[num2]);

?>