<?php
for($i=1;$i<=10;$i++)
{
if($i%2==0)
{
echo $i."<br>"; //246810 even number
}
}
?>