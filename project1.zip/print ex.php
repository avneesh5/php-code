<?php
$x=100;
$y=200;
print $x;
print "<br>";
print $y;
?>