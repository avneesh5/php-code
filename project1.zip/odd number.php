<?php
for($i=1;$i<=10;$i=$i+2)
{
echo $i."<br>"; //13579
}

?>