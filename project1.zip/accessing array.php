<?php
$mix=array(10.5,true,"weight",123);
echo $mix[0]."<br>";
echo $mix[1]."<br>";
echo $mix[2]."<br>";
echo $mix[3]."<br>";

?>