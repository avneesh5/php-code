<?php
echo "<h1>welcome</h1>";
echo "<p>hello</p>";
echo "<div>azamgarh</div>";


?>