<?php
header("content-disposition:attachment;filename=project1.zip");
readfile("aviproject1.zip");
?>