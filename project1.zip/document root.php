<pre>
<?php
echo $_SERVER['DOCUMENT_ROOT'];//C:xampp/htdocs root directory
?>