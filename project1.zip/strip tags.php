<pre>
<?php

$name="<h1>Ram</h1>";
echo strip_tags($name); //Ram
?>