<?php
$x=100;
echo isset($x);  //1
?>