<pre>
<?php
$x=100;
$arr=array(10,20,30);
var_dump($arr);
var_dump($x);
?>