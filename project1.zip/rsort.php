<pre>
<?php
$arr=array("Ram","Sam","Tam","abc","hin");
echo rsort($arr);
print_r($arr);
// reverse sort
?>