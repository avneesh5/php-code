<pre>
<?php
$pwd="ram@123";
echo sha1($pwd);
//6a660357993859347877bfe7399d962626fe352e       40bit


?>