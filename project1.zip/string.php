<?php
echo "welcome to php"."<br>";
echo "welcome to php class"."<br>";
echo "this is \"PHP\" class"."<br>";
echo "hello this is Ram\'s class";

?>