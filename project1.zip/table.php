<?php
for($j=2;$j<=20;$j++)
{
$table=$j;
for($i=1;$i<=10;$i++)
{
echo $table."*".$i."=".$table*$i;
echo "<br>";
}
echo "<br>=====================<br>";
}
?>