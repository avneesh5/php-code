<?php
echo <<<'xyz'
<html>
<head>
<title>
Nowdoc</title>
</head>
<body>
<h1>test</h1>
</body>
</html>
xyz;


?>