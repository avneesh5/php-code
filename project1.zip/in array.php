<pre>
<?php
$arr=array("abc","def","ghi",10,20,30,40);
echo in_array(20,$arr);  //1
echo in_array("ijk",$arr);  // empty



?>