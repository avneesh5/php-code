<pre>
<?php
$folder="images";
if(file_exists($folder))
{
    rmdir($folder);
echo "folder deleted.....";
}
else
{
echo "folder not exists.....";
}

?>