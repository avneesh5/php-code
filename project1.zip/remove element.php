<pre>
<?php
$arr=array(10,20,30,40,50,60);
unset($arr[2]); //30
print_r($arr);


?>