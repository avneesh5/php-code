<pre>
<?php
$fp=fopen("hi.txt","w");
echo fwrite($fp,"hii how are you");
?>