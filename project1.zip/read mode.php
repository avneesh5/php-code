<?php
$tp=fopen("hi.txt","r");
echo fread($tp,100);


?>