<?php
date_default_timezone_set("Asia/Kolkata");
echo date(" d-m-Y h:i:sa D F");

?>