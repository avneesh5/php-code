<pre>
<?php
$arr=array(10,20,30,50,70); //5
echo count($arr);



?>