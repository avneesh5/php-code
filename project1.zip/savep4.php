<?php
$n1=$_COOKIE['value1'];
$n2=$_COOKIE['value2'];
//$n2=$_POST['num2'];
$n3=$_POST['num3'];
$sum=$n1+$n2+$n3;
echo "the sum is $sum";






?>