<?php
$email="avms@gmail.com";
echo strpos($email,"gmail"); //5

?>