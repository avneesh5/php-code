<html>
<head>
    <title> multiple file uploading</title>
    </head>
<body>
    <h1> Multiple File uploading</h1>
    <p><b>Note:</b>please upload a file of type<b> .PNG, .JPG, .JPEG</b></p>
    <p><b>Note: </b><b>File size should below 2MB</b></p>
    <?php
    if(isset($_POST['upload']))
    {
        $c=count($_FILES['image']['name']);
        for($i=0;$i<$c;$i++)
        {
    if(is_uploaded_file($_FILES['image']['tmp_name'][$i]))
    {
        echo"<pre>";
        $filename=$_FILES['image']['name'][$i];
        $size=$_FILES['image']['size'][$i];
        $type=$_FILES['image']['type'][$i];
        $tname=$_FILES['image']['tmp_name'][$i];
         //validation
    $str=str_shuffle("abcdefghijklmnopqrstuvwxyz");
    $ext=substr($str,10,10);
    $newfilename=$ext."=".$filename;
    if($type="image/jpg" || $ttype="image/png" ||$type="image/jpeg")
    {
    if(move_uploaded_file($tname,"uploads/$newfilename"))
    {
    echo "<p>File uploaded successfully</p>";
    }
    }
    else
    {
    echo "<p>Please select a valid file to upload</p>";
    }
    }
    else
    {
    echo "<p>Please select a file to upload</p>";
    }
    }
    }
    ?>
    <form method="POST" action="" enctype="multipart/form-data">
    upload avatar:<input type="file" name="image[]" multiple><br>
    <input type="submit" name="upload" value="submit">
    
    </form>
    </body>
</html>