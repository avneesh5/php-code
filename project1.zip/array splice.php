<pre>
<?php
$arr=array(10,20,30,40,50,60,70,80,90);
array_splice($arr,2,0,500);
print_r($arr);
?>