<html>
<head>
<title>file uploading</title>
    </head>
<body>
    <h1>file uploading</h1>
<?php
if(isset($_POST['uplooad']))
{
    //echo "pre";
    //print_r($_FILES);
  if(is_uploaded_file($_FILES['image']['tmp_name']))  
    $filename=$_FILES['image']['name'];
    $size=$_FILES['image']['size'];
    $type=$_FILES['image']['type'];
    $tname=$_FILES['image']['tmp_name'];
    $error=$_FILES['image']['error'];
    $status=move_uploaded_file($tname,
    "uploads/$filename");
    if ($status==1)
    {
    echo "<p>file upload sucessfully</p>";
    }
    else
    {
    echo "<p>please select a file to upload</p>";
    
    }
}
 ?>
    <form method="POST" acttion="" enctype="multipart/form-data">
select a file to upload:<input type="file" name="image"><br>
<br>
<input type="submit" name="upload" value="submit">
</form>
</body>
    </html>
