<pre>
<?php
$num=1234567890;
echo substr(str_shuffle($num),0,6);


?>