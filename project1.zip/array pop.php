<pre>
<?php
$arr=array(10,20,30,40,50,60);
echo array_pop($arr); //60
echo array_pop($arr);  //50
print_r($arr);


?>