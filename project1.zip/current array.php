<pre>
<?php
$arr=array("ram","Ram","sam","Sam");
echo current($arr);  //ram


?>