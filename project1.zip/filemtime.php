<pre>
<?php
echo date("l y-m-d h:i:s a",filemtime(explode.php) );


?>