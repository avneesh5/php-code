<pre>
<?php
$str="Avneesh kumar mishra";
echo strtoupper($str);
?>

