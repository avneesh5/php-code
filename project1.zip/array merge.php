<pre>
<?php
$a1=array(10,20,30,40);
$a2=array(100,200,300,400);
$a3=array("a",'b',"c");
$fa=array_merge($a1,$a2,$a3);

print_r($fa);



?>