<pre>
<?php
$arr=array("Ram","Sam","Tam","abc","hin");
echo asort($arr);
print_r($arr);

?>