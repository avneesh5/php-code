<pre>
<?php
print_r($_REQUEST);
$name=$_REQUEST['Name'];
$mail=$_REQUEST['Email'];
?>