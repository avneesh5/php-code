<pre>
<?php
$arr=array(4=>20,30,40,50);
print_r($arr);

?>