<pre>
<?php
$pwd="ram@123";
echo password_hash($pwd,PASSWORD_DEFAULT);
//  $2y$10$W/r5RekffW66vBX3joGPb.8Dgjc/9NSPPshFMGYX336E/TdI02EVe


?>