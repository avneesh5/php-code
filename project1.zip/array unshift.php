<pre>
<?php
$arr=array(10,20,30,40,50,60);
echo array_unshift($arr,70); //7
echo array_unshift($arr,90);  //8
print_r($arr);


?>