<!DOCTYPE html>
    <html>
<head>
</head>
<body>
<h1>person2</h1>
<form method="POST" action="savep3.php">    
Number2:<input type="text" name="num2">
<input type="submit" value="go">
    </form>
    </body>
    </html>
<?php
setcookie("value1",$_POST[num1]);

?>